<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('C:\laragon\www\percobaanskripsi_1\storage\framework/views/livewire/views/e68d358d.blade.php', $data);
    }
}; 