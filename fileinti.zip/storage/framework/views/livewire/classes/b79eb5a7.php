<?php

use Livewire\Component;
use Livewire\Attributes\Title;

return new #[Title('Appearance settings')] class extends Component {
    //

    protected function view($data = [])
    {
        return app('view')->file('C:\laragon\www\percobaanskripsi_1\storage\framework/views/livewire/views/b79eb5a7.blade.php', $data);
    }
}; 